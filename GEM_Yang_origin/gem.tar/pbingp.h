                i=int(xt/dx+0.5)
                j=int(yt/dy+0.5)
                k=int(z3(ns,m)/dz+0.5)-gclr*kcnt

                aparhp = aparhp+apar(i,j,k)
